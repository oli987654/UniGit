# Please do not modify this part of the code!
a = 1
b = 10
c = 3
d = 2

# Your code goes here
task_2_a_1 = # expression 1
print(task_2_a_1)

task_2_a_2 = # expression 2
print(task_2_a_2)