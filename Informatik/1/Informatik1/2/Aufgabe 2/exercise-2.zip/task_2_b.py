# Please do not modify this part of the code! 
# This is just to show how you should name the variables containing your answers
task_0 = 'Python is cool!' * 3
print('Task 0:', task_0)


# Your code goes here
# Task 1
task_1 = 

# Task 2
doghouse = "doghouse"
task_2_p1 = 
task_2_p2 = 

# Task 3
task_3 = 

# Task 4
task_4 = 

# Task 5
task_5 = 

# Task_6
task_6 = 