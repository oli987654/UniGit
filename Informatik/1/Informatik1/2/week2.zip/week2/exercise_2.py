name = input('What is your name?')
age = input('How old are you?')
occupation = input('What is your occupation?')
print('Hi %s! I see you are %s years old and work as a %s.' % (name, age, occupation))
