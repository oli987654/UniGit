n = int(input('n = '))
total_sum = 0
for count in range(1, n + 1):
    total_sum += count
print('The sum of the first %d values is %d.' % (n, total_sum))
