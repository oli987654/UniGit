import random
rand_val = random.randint(0, 100)
print(rand_val)
while True:
    guess_val = int(input('guess: '))
    if rand_val < guess_val:
        print('less')
    elif rand_val > guess_val:
        print('larger')
    else:
        print('correct!')
        break
