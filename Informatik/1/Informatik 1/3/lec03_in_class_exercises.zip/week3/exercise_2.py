phone_number = input("Please enter a phone number: ")
if len(phone_number) != 10:
    print("Your phone number should be 10 digits long!")
else:
    invalid_character = False
    for ch in phone_number:
        # check if ch is different from 0, 1 and 2
        if ch != "0" and ch != "1" and ch != "2":
            invalid_character = True
            break
    if invalid_character:
        print("Found an invalid character")
    else:
        if phone_number[0] == "0" and phone_number[1] == "1" and phone_number[2] == "1":
            print("Valid")
        else:
            print("Does not start with 011")




