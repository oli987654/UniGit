while True:
    grades_sum = 0
    num_grades = 0
    while True:
        grade = float(input('grade = '))
        if grade == -1:
            avg = grades_sum / num_grades
            print('Average grade = %.2f' % avg)
            break
        grades_sum += grade
        num_grades += 1
    answer = input('continue? ')
    if answer != "Yes":
        break

