n = int(input('n = '))
total_sum = 0
count = 0
while count < n:
    count += 1
    total_sum += count
print('The sum of the first %d values is %d.' % (n, total_sum))
