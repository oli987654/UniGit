# Please do not modify this part of the code!
a = 1
b = 10
c = 3
d = 2

# Your code goes here
task_2_a_1 = a-(b**2/(d-c*(d+d)))
print(task_2_a_1)

task_2_a_2 = 13%5
print(task_2_a_2)