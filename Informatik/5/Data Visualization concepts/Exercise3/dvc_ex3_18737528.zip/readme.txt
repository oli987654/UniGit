Additional modules used:
bokeh.layouts columns

