T1.2 a) In datasets with a lot of variation, the individual values by themselves might not say a lot, while the averages over a subset of the values might. Smoothing out the data can also insure that statistical outliers are brought back to a better value.

b) The higher the window size the more homogeneous the results become.