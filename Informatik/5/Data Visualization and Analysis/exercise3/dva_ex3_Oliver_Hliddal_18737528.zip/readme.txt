Additional modules used:
random
from bokeh.events import ButtonClick